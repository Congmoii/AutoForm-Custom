# AutoForm-Custom v4.0.15

Tiện ích Chrome Manifest V3 để quét và điền Google Forms theo cấu hình tỷ lệ, CSV hoặc lịch. Đây là bản cài thủ công, không phải tiện ích trên Chrome Web Store.

## Cài đặt từ gói ZIP

1. Tải tệp ZIP của bản phát hành và **giải nén** ra một thư mục cố định.
2. Mở `chrome://extensions`, bật **Chế độ dành cho nhà phát triển**.
3. Chọn **Tải tiện ích đã giải nén** và chọn thư mục vừa giải nén **có `manifest.json` ở ngay bên trong**.
4. Giữ nguyên thư mục đó sau khi cài. Khi cập nhật, giải nén bản mới và nạp lại tiện ích trên trang Extensions.

Chrome không cài trực tiếp tiện ích bằng cách kéo tệp ZIP vào cửa sổ. Bản cài thủ công cũng không tự cập nhật qua Chrome Web Store.

Chỉ chạy một phiên quét/điền tại một thời điểm. Nên thử trên biểu mẫu thử nghiệm trước; kết quả kiểm thử với biểu mẫu mô phỏng không thay thế việc kiểm chứng trên Google Forms thật. Không dùng tính năng gửi lặp cho biểu mẫu của người khác khi chưa được cho phép.

## Dành cho người phát triển

Chạy `npm ci`, `npm test`, `npx tsc --noEmit` và `npm run build`. Mã nguồn giao diện nằm trong `src/popup`; gói cài thủ công chỉ cần các tệp runtime, `dist-popup` và `Images`.
